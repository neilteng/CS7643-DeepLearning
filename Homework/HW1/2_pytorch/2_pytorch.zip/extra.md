### Use VGGNET-like structure

1 [conv+relu+conv+relu+pool]*2 + [conv+relu+conv+relu+conv+relu+pool] + [affine+relu]*2 + affine + softmax

2 Using momentum SGD for gradient descent

3 Tuning parameter for up to 80%+ validation accuracy 
